package Alimento;

public interface Saludable {
    
    //VARIABLES:
    
    public String getTipo();
    public int getCalorias();
}