
public class Familiar {

}
